package com.order.model;

import java.time.LocalDate;

import lombok.Data;

@Data
public class OrderDTO {
	private Integer orderId;
	private Integer userId;
	private String orderStatus;
	private Double orderAmount;
	private LocalDate orderDate;
}
