package com.order.service;

import com.order.exception.OrderException;
import com.order.model.OrderDTO;

public interface OrderService {

	OrderDTO getOrderById(Integer orderId) throws OrderException;

}
