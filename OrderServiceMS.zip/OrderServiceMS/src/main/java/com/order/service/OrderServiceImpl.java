package com.order.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.order.entity.Order;
import com.order.exception.OrderException;
import com.order.model.OrderDTO;
import com.order.repository.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService{
	
	@Autowired
	private OrderRepository orderRepository;

	@Override
	public OrderDTO getOrderById(Integer orderId) throws OrderException{
		Optional<Order> optional = orderRepository.findById(orderId);
		
		OrderDTO orderDTO = new OrderDTO();
		try {
			Order order = optional.orElseThrow(()-> new OrderException("Order not found: "));
			
			orderDTO.setOrderId(order.getOrderId());
			orderDTO.setUserId(order.getUserId());
			orderDTO.setOrderStatus(order.getOrderStatus());
			orderDTO.setOrderAmount(order.getOrderAmount());
			orderDTO.setOrderDate(order.getOrderDate());
		} catch (OrderException e) {
			
			e.printStackTrace();
		}
		return orderDTO;
		
	}

}
