package com.order.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;
import lombok.Data;
import java.time.LocalDate;

@Entity
@Data
@Table(name = "orders") 
//Order is the table name(Entity)
public class Order {
	
	@Id
	@TableGenerator(name = "order_gen", initialValue = 5010, allocationSize = 1,
			table = "order_seq", pkColumnName = "seq_name", valueColumnName = "seq_value")
	@GeneratedValue(generator = "order_gen")
	//These attributes are the column names
	private Integer orderId;
	private Integer userId;
	private String orderStatus;
	private Double orderAmount;
	
	//@Column(name="data")
	private LocalDate orderDate;

}
